package router

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"os"
	"time"

	"../crawler"
)

// TemplateData struct to hold on the values passed to template
type TemplateData struct {
	Domains map[string]int
	Time    string
}

// Run start up the router
func Run() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "5000"
	}
	mux := http.NewServeMux()
	// Call function when navigated to respective page
	mux.HandleFunc("/", statusPage)

	mux.HandleFunc("/getDomainInfo", domainInfo)

	// Heartbeat
	mux.HandleFunc("/health",
		func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "Ok")
		})

	// Start go routine for server to listen on port
	http.ListenAndServe(":"+port, mux)
}

func statusPage(w http.ResponseWriter, r *http.Request) {
	// Get status map(dict) from crawler
	status := crawler.GetStatus()
	// Format datetime value; Must use exact reference time string shown
	t := time.Now().Format("Mon Jan _2 15:04:05 2006")

	// Parse template that will be execute with passed in data struct
	tmpl := template.Must(template.ParseFiles("templates/index.html"))

	// Create data struct that will pass in status map, and time to template
	data := TemplateData{status, t}

	// Display template with data
	tmpl.Execute(w, data)
}

// Return domain status card info for front-end
func domainInfo(w http.ResponseWriter, r *http.Request) {
	// set CORS header so we can test
	w.Header().Set("Access-Control-Allow-Origin", "*")

	domainStatus := crawler.GetStatus()
	// jsonify domain status map
	statusJSON, _ := json.Marshal(domainStatus)
	// right out status response
	fmt.Fprint(w, string(statusJSON))
}
