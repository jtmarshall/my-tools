package crawler

import (
	"database/sql"
	"log"
	"time"
	"fmt"
)

var (
	// DB connection creds
	host = "monitoring-dev1.clkd4diaelqh.us-east-1.rds.amazonaws.com"
	dbName = "monitor"
	user = "acadia"
	pass = "%" + "G803$h#dOAu"
	connectString = user + ":" + pass + "@tcp(" + host + ")/" + dbName
)
// Struct to create format for Domain metrics
type DomainStats struct {
	AvgRespTime float64
	MaxRespTime float64
	AvgTTFB float64
	MaxTTFB float64
	CountURL int
	TotalErr int
}
// Properties for 404 email
type Four04Props struct {
	Domain    sql.NullString
	Referer   sql.NullString
	TimeStamp time.Time
}


// GetDomainList Query DB for Domain list
func getDomainList() {
	// DB connect
	db, err := sql.Open("mysql", connectString)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	var (
		id     int
		domain string
	)

	rows, err := db.Query("SELECT id, Domain FROM status")
	if err != nil {
		log.Fatal(err)
	}

	// clear list before we start adding again
	domainList = domainList[:0]

	for rows.Next() {
		err := rows.Scan(&id, &domain)
		if err != nil {
			log.Fatal(err)
		}
		domainList = append(domainList, domain)
	}
	err = rows.Err()
	if err != nil {
		log.Fatal(err)
	}
	// Manually Close
	rows.Close()
}

// Insert standard info into page table
// *!* Pass in DB pointer to avoid connection overflow!!! *!*
func insertPage(dbIn *sql.DB, domain string, url string, code int, respTime float64,
	ttfb float64, urlErr string, redirects int, crawlID int) {

	// Insert crawl info into DB
	_, err2 := dbIn.Exec(
		`INSERT INTO page (Domain, url, datetime, status_code, response_time, ttfb, error, redirects, crawl_id) 
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		domain, url, time.Now(), code, respTime, ttfb, urlErr, redirects, crawlID)
	if err2 != nil {
		log.Fatal(err2)
	}
	// fmt.Println("Finish InsertDB Func")
}


// Called if status code is 5xx, insert info into outages table
func handleOutage(dbIn *sql.DB, domain string, url string, code int, crawlID int, refererURL string) {
	// Check if we need to send an email alert
	if code == 504 {
		last2H := time.Now().Add(-2 * time.Hour)  // Datetime for 2 hours ago (roughly time of last all crawl)
		totalErr := 0

		// Query for previous outages within the last 2 hours; so we don't spam email
		outage, outageErr := dbIn.Query("SELECT COUNT(id) FROM outages WHERE datetime < ? AND Domain = ?",
			last2H, domain)
		if outageErr != nil {
			log.Fatal(outageErr)
		}
		defer outage.Close()

		for outage.Next() {
			outErr := outage.Scan(&totalErr)
			if outErr != nil {
				log.Fatal(outErr)
			}
		}

		// Send error to daemon to handle email
		DaemonAddError(url)
	}

	// Insert outage into DB outages table
	_, err2 := dbIn.Exec(
		"INSERT INTO outages (Domain, page, datetime, status_code, crawl_id, Referer) VALUES (?, ?, ?, ?, ?, ?)",
		domain, url, time.Now(), code, crawlID, refererURL)
	if err2 != nil {
		log.Fatal(err2)
	}
}


// After Domain crawl update status table
func updateStatus(domain string, crawlID int, dbIn *sql.DB) {
	var (
		avgRespTime float64 = 0
		maxRespTime float64 = 0
		avgTTFB float64 = 0
		maxTTFB float64 = 0
		countURL = 0
		totalErr = 0
		totalCrawled = 0
	)

	// Defer always update status with zeroes if needed
	defer func() {
		// Update status table for Domain
		_, updateErr := dbIn.Exec(
			`UPDATE status SET datetime = ?, avg_ttfb = ?, avg_response = ?, total_errors = ?, total_urls = ?,
					max_response = ?, max_ttfb = ? WHERE Domain = ?`,
			time.Now(), avgTTFB, avgRespTime, totalErr, countURL, maxRespTime, maxTTFB, domain)
		if updateErr != nil {
			fmt.Println("UPDATE ERR: ", updateErr)
			return
		}
	}()

	// Defer always update crawl time
	defer func() {
		// Finally update crawl end time after all stuff for this Domain is done
		// Update "end_time" for crawlID
		_, updateCrawlErr := dbIn.Exec(
			"UPDATE crawl SET end_time = ? WHERE id = ?", time.Now(), crawlID)
		if updateCrawlErr != nil {
			fmt.Println("UPDATE CRAWL ERR: ", updateCrawlErr)
			return
		}
	}()


	// Query for page STATS
	page, queryErr := dbIn.Query(
		`SELECT AVG(response_time), MAX(response_time), AVG(ttfb), MAX(ttfb), COUNT(id)
				FROM page WHERE crawl_id = ? AND Domain = ?`,
		crawlID, domain)
	if queryErr != nil {
		fmt.Println("QUERY PAGE ERR: ", queryErr)
		return
	}
	defer page.Close()

	for page.Next() {
		scanErr := page.Scan(&avgRespTime, &maxRespTime, &avgTTFB, &maxTTFB, &countURL)
		if scanErr != nil {
			fmt.Println("PAGE.NEXT ERR: ", scanErr)
			return
		}
	}


	// Query for outages/errors
	outage, outageErr := dbIn.Query("SELECT COUNT(id) FROM outages WHERE crawl_id = ? AND Domain = ?",
		crawlID, domain)
	if outageErr != nil {
		fmt.Println("OUTAGE ERR: ", outageErr)
		return
	}
	defer outage.Close()

	for outage.Next() {
		outErr := outage.Scan(&totalErr)
		if outErr != nil {
			fmt.Println("OUTAGE.NEXT ERR: ", outErr)
			return
		}
	}


	// Get total_crawled urls for whole crawlID, so far
	crawlCount, crawlCountErr := dbIn.Query("SELECT COUNT(id) FROM page WHERE crawl_id = ?", crawlID)
	if crawlCountErr != nil {
		fmt.Println("CRAWL COUNT ERR: ", crawlCountErr)
		return
	}
	defer crawlCount.Close()

	for crawlCount.Next() {
		countErr := crawlCount.Scan(&totalCrawled)
		if countErr != nil {
			fmt.Println("CRAWL COUNT.NEXT ERR: ", countErr)
			return
		}
	}


	// Update "total_crawled" for crawl table
	_, updateTotalCrawedlErr := dbIn.Exec(
		"UPDATE crawl SET total_crawled = ? WHERE id = ?", totalCrawled, crawlID)
	if updateTotalCrawedlErr != nil {
		fmt.Println("UPDATE TOTAL_CRAWLED ERR: ", updateTotalCrawedlErr)
		return
	}
}


// Daily404 emails out found 404's from the previous day every morning
func Daily404() {
	// DB connect
	db, err := sql.Open("mysql", connectString +"?parseTime=true")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Create map for 404url keys and properties values
	four04Map := map[string]*Four04Props{}

	toTime := time.Now()
	// get last day
	fromTime := toTime.AddDate(0, 0, -1)

	// Query for 404
	query404, queryErr := db.Query(
		`SELECT Domain, page, datetime, Referer FROM outages WHERE status_code = ? AND datetime BETWEEN ? AND ?`,
		404, fromTime, toTime)
	if queryErr != nil {
		fmt.Println("QUERY404 PAGE ERR: ", queryErr)
	}
	defer query404.Close()

	for query404.Next() {
		var page string
		props := Four04Props{}

		scan404Err := query404.Scan(&props.Domain, &page, &props.TimeStamp, &props.Referer)
		if scan404Err != nil {
			fmt.Println("query404.NEXT ERR: ", scan404Err)
			break
		}
		// add 404 page to map with properties from query
		four04Map[page] = &props
	}

	if len(four04Map) > 0 {
		// Pass 404 map to compose and send email func
		EmailDaily404(four04Map)
	}
}


// WeeklyReport to query stats for all domains and send email once a week
func WeeklyReport() {
	// DB connect
	db, err := sql.Open("mysql", connectString)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Create map for Domain keys and DomainsStats values
	statusMap := map[string]*DomainStats{}

	// 7 day time frame previous to now
	toTime := time.Now()
	fromTime := toTime.AddDate(0, 0, -7)

	// Loop through all domains getting metrics
	for _, domain := range domainList {
		// Reset vars for every Domain
		var (
			// Use nullable types for temp values so the scan doesn't throw a fit
			avgRespTime sql.NullFloat64
			maxRespTime sql.NullFloat64
			avgTTFB sql.NullFloat64
			maxTTFB sql.NullFloat64
			countURL = 0
			totalErr = 0
		)

		// Query for page STATS
		page, queryErr := db.Query(
			`SELECT AVG(response_time), MAX(response_time), AVG(ttfb), MAX(ttfb), COUNT(id)
					FROM page WHERE Domain = ? AND datetime BETWEEN ? AND ?`,
			domain, fromTime, toTime)
		if queryErr != nil {
			fmt.Println("QUERY PAGE ERR: ", queryErr)
			break
		}
		defer page.Close()

		for page.Next() {
			scanErr := page.Scan(&avgRespTime, &maxRespTime, &avgTTFB, &maxTTFB, &countURL)
			if scanErr != nil {
				fmt.Println("PAGE.NEXT ERR: ", scanErr)
				break
			}
		}

		// Query for outages/errors
		outage, outageErr := db.Query("SELECT COUNT(id) FROM outages WHERE Domain = ? AND datetime BETWEEN ? AND ?",
			domain, fromTime, toTime)
		if outageErr != nil {
			fmt.Println("OUTAGE ERR: ", outageErr)
			break
		}
		defer outage.Close()

		for outage.Next() {
			outErr := outage.Scan(&totalErr)
			if outErr != nil {
				fmt.Println("OUTAGE.NEXT ERR: ", outErr)
				break
			}
		}

		// Assign struct values to Domain
		statusMap[domain] = &DomainStats{
			// Get "real" float values from nullable types, and round them to 2 decimals before setting Domain values
			AvgRespTime: avgRespTime.Float64,
			MaxRespTime: maxRespTime.Float64,
			AvgTTFB: avgTTFB.Float64,
			MaxTTFB: maxTTFB.Float64,
			CountURL: countURL,
			TotalErr: totalErr}
	}
	// END Domain loop

	// Send email with passed in status map
	WeeklyEmail(statusMap, domainList)
}


// DeleteOldData removes rows from DB that are more than 30 days old
func DeleteOldData() {
	// 30 day time frame from now
	oldTime := time.Now().AddDate(0, 0, -30)

	// DB connect
	db, err := sql.Open("mysql", connectString)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	// Delete rows from page older than 30 days
	_, deletePageErr := db.Exec(
		"DELETE FROM page WHERE datetime < ?", oldTime)
	if deletePageErr != nil {
		fmt.Println("DELETE PAGE ERR: ", deletePageErr)
	}

	// Delete rows from crawl older than 30 days
	_, deleteCrawlErr := db.Exec(
		"DELETE FROM crawl WHERE end_time < ?", oldTime)
	if deleteCrawlErr != nil {
		fmt.Println("DELETE CRAWL ERR: ", deleteCrawlErr)
	}

	// Delete rows from outage older than 30 days
	_, deleteOutagesErr := db.Exec(
		"DELETE FROM outages WHERE datetime < ?", oldTime)
	if deleteOutagesErr != nil {
		fmt.Println("DELETE OUTAGES ERR: ", deleteOutagesErr)
	}
}
