package crawler

import (
	"log"
	"net/smtp"
	"html/template"
	"strings"
	"fmt"
	"time"
	"sort"
	"bytes"
)

var (
	// AWS Config
	emailHost     = "email-smtp.us-east-1.amazonaws.com"
	emailHostUser = "AKIAJGJPEXULW6SZCIGA"
	emailHostPass = "ApVjUaGVIPiAkGJC3Y8ZmMxSdVAoDQ7Fu6QHVWhmDLcD"
	emailPort     = ":587"

	// Emails
	soloEmail = []string{"jordan.marshall@acadiahealthcare.com"}
	fromaddr = "Monitor@acadiahealthcare.com"
	toaddr   = []string{"jordan.marshall@acadiahealthcare.com", "eric.austin@acadiahealthcare.com", "edwin.orjales@acadiahealthcare.com"}
)


// EmailDaily404 sends out 404 list everyday
func EmailDaily404(four04Set map[string]*Four04Props) {
	// Set up authentication information.
	auth := smtp.PlainAuth("", emailHostUser, emailHostPass, emailHost)

	currentTime := time.Now().Format(time.Stamp)

	// To store the keys in slice in sorted order
	var keys []string
	for k := range four04Set {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	// templateData struct to pass sorted keys and four04Set to html template
	templateData := struct {
		SortedKeys []string
		ErrSet map[string]*Four04Props
	}{ keys,four04Set }

	// Parse template that will be execute with passed in data struct
	tmpl, _ := template.ParseFiles("templates/email404.html")

	// byte buffer to read in template with data
	buf := new(bytes.Buffer)
	tmpl.Execute(buf, templateData)

	toHead := "To: "+ strings.Join(toaddr, ",") +"\r\n"
	subject := "Subject: Monitor: 404 List " + currentTime + " \n"
	mime := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\n\n"

	// Setup message to send
	msg := []byte(toHead + subject + mime + "\n")
	//
	msg = append(msg, buf.Bytes()...)

	// Connect to the server, authenticate, set the sender, recipient, and pass in the msg
	emailErr := smtp.SendMail(emailHost+emailPort, auth, fromaddr, toaddr, msg)
	if emailErr != nil {
		log.Fatal(emailErr)
	}
}

// EmailAlert notifies email list of error; without Domain needed
func EmailAlert(url string, code int) {
	// Set up authentication information.
	auth := smtp.PlainAuth("", emailHostUser, emailHostPass, emailHost)

	// Setup message to send
	msg := []byte(
		"To: "+ strings.Join(toaddr, ",") +"\r\n" +
			"Subject: Monitor: " + fmt.Sprint(code) + " Alert\r\n" + "\r\n" +
			"Status: " + fmt.Sprint(code) + "\r\n" +
			"On page: " + url + "\r\n" +
			"Time: " + time.Now().Format(time.Stamp))

	// Connect to the server, authenticate, set the sender, recipient, and pass in the msg
	err := smtp.SendMail(emailHost+emailPort, auth, fromaddr, toaddr, msg)
	if err != nil {
		log.Fatal(err)
	}
}


// BackOnline notifies email list of a Domain recovering from 5xx status
func BackOnline(domain string, url string, code int) {
	// Set up authentication information.
	auth := smtp.PlainAuth("", emailHostUser, emailHostPass, emailHost)

	// Setup message to send
	msg := []byte(
		"To: "+ strings.Join(toaddr, ",") +"\r\n" +
			"Subject: Monitor: Domain Recovered\r\n" + "\r\n" +
			domain + " is back online. \r\n" +
			"Status: " + fmt.Sprint(code) + "\r\n" +
			"On page: " + url + "\r\n" +
			"Time: " + time.Now().Format(time.Stamp))

	// Connect to the server, authenticate, set the sender, recipient, and pass in the msg
	err := smtp.SendMail(emailHost+emailPort, auth, fromaddr, toaddr, msg)
	if err != nil {
		log.Fatal(err)
	}
}


// WeeklyEmail sends out automatic email every week
func WeeklyEmail(summSet map[string]*DomainStats, domainList []string)  {
	// Set up authentication information.
	auth := smtp.PlainAuth("", emailHostUser, emailHostPass, emailHost)

	toHead := "To: "+ strings.Join(toaddr, ",") +"\r\n"
	subject := "Subject: Monitor: Weekly Report \n"
	mime := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\n\n"

	// Setup message to send
	msg := []byte(toHead + subject + mime + "\n")
	formatTxt := []byte(`<table border="0" cellpadding="1" cellspacing="0" height="100%" id="bodyTable">`)
	msg = append(msg, formatTxt...)

	// We must iterate through the sorted list of domains for the report to be alphabetical;
	// 	rather than just through the given map because map iteration order is intentionally undefined.
	for _, domain := range domainList {

		// Create text byte chunk for Domain
		domainTxt := []byte(
			`
			<tr>
				<td align="left" valign="top">
					<table border="0" cellpadding="4" cellspacing="0" width="400" id="emailContainer">
						<tr>
							<h3> `+ domain +` </h3>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Avg Response: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprintf("%.2f", summSet[domain].AvgRespTime) +`<i>ms</i>
							</td>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Max Response: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprintf("%.2f", summSet[domain].MaxRespTime) +`<i>ms</i>
							</td>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Avg TTFB: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprintf("%.2f", summSet[domain].AvgTTFB) +`<i>ms</i>
							</td>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Max TTFB: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprintf("%.2f", summSet[domain].MaxTTFB) +`<i>ms</i>
							</td>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Total Crawled: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprint(summSet[domain].CountURL) +`
							</td>
						</tr>
						<tr>
							<td align="left" valign="top">
								<b>Total Errors: </b>
							</td>
							<td align="left" valign="top">
								`+ fmt.Sprint(summSet[domain].TotalErr) +`
							</td>
						</tr>
						<tr>
							<td> </td> <td> </td>
						</tr>
					</table>
				</td>
			</tr>
			`)

		// Append Domain text chunk to msg
		msg = append(msg, domainTxt...)
	}

	endFormatTxt := []byte(`</table>`)
	msg = append(msg, endFormatTxt...)

	// Connect to the server, authenticate, set the sender, recipient, and pass in the msg
	err := smtp.SendMail(emailHost+emailPort, auth, fromaddr, toaddr, msg)
	if err != nil {
		log.Fatal(err)
	}
}
