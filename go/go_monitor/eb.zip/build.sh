go get github.com/go-sql-driver/mysql
go get golang.org/x/net/html
go get github.com/robfig/cron
go build -o bin/application application.go